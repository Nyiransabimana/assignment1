/** Automatically generated file. DO NOT MODIFY */
package com.example.venuste;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}