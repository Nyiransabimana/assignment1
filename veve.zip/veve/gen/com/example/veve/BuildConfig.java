/** Automatically generated file. DO NOT MODIFY */
package com.example.veve;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}